HISTORY DUO - 7-bosqich paketi
Asos: history_duo_stage6.zip
Yangi: natijalar tarixi, foydalanuvchini bloklash, shikoyat yuborish, Firestore xavfsizlik qoidalari.
Ilova manbasi: app_src/
Firebase qoidalari: firestore.rules
Tafsilot va sinovlar: STAGE7_README.txt
