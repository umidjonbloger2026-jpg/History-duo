class Section {
  final String title;
  final String text;
  const Section({required this.title, required this.text});

  factory Section.fromMap(Map<String, dynamic> m) => Section(
        title: (m['title'] ?? '') as String,
        text: (m['text'] ?? '') as String,
      );

  Map<String, dynamic> toMap() => {'title': title, 'text': text};
}

class Topic {
  final String id;
  final String title;
  final List<Section> sections;
  const Topic({required this.id, required this.title, required this.sections});

  factory Topic.fromMap(Map<String, dynamic> m) => Topic(
        id: (m['id'] ?? '') as String,
        title: (m['title'] ?? '') as String,
        sections: ((m['sections'] as List?) ?? [])
            .map((e) => Section.fromMap(Map<String, dynamic>.from(e as Map)))
            .toList(),
      );

  Map<String, dynamic> toMap() => {
        'id': id,
        'title': title,
        'sections': sections.map((s) => s.toMap()).toList(),
      };
}

class Book {
  final String id;
  final String title;
  final String description;
  final bool isCustom;
  final List<Topic> topics;
  const Book({
    required this.id,
    required this.title,
    required this.description,
    required this.isCustom,
    required this.topics,
  });

  factory Book.fromMap(Map<String, dynamic> m,
      {required String id, required bool isCustom}) {
    return Book(
      id: id,
      title: (m['title'] ?? '') as String,
      description: (m['description'] ?? '') as String,
      isCustom: isCustom,
      topics: ((m['topics'] as List?) ?? [])
          .map((e) => Topic.fromMap(Map<String, dynamic>.from(e as Map)))
          .toList(),
    );
  }
}

/// Sherik topishda tanlangan kitob va mavzu (4-bosqichda ishlatiladi).
class TopicSelection {
  final Book book;
  final Topic topic;
  const TopicSelection(this.book, this.topic);
}
