import 'package:flutter/material.dart';
import '../core/theme.dart';
import '../models/book.dart';
import '../services/auth_service.dart';
import '../services/book_service.dart';
import '../widgets/animated_helpers.dart';
import 'book_detail_screen.dart';

/// Kitoblar ro'yxati. pickMode=true bo'lsa, tanlangan mavzu (TopicSelection)
/// qaytariladi (4-bosqichda "Sherik topish" shu rejimdan foydalanadi).
class BooksScreen extends StatelessWidget {
  final bool pickMode;
  const BooksScreen({super.key, this.pickMode = false});

  Future<void> _open(BuildContext context, Book b) async {
    final res = await Navigator.of(context).push<TopicSelection>(
      MaterialPageRoute(
          builder: (_) => BookDetailScreen(book: b, pickMode: pickMode)),
    );
    if (pickMode && res != null && context.mounted) {
      Navigator.of(context).pop(res);
    }
  }

  Future<void> _addBook(BuildContext context) async {
    final t = TextEditingController();
    final d = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.navy,
        title: const Text("Yangi kitob"),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: t,
              maxLength: 60,
              autofocus: true,
              decoration: const InputDecoration(labelText: "Kitob nomi"),
            ),
            TextField(
              controller: d,
              maxLength: 140,
              decoration:
                  const InputDecoration(labelText: "Qisqa tavsif (ixtiyoriy)"),
            ),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text("Bekor qilish")),
          TextButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text("Qo'shish")),
        ],
      ),
    );
    final title = t.text.trim();
    final desc = d.text.trim();
    if (ok != true || title.length < 2) return;
    try {
      await BookService.instance.addBook(title, desc);
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(friendlyError(e))));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(pickMode ? "Kitob tanlang" : "Kitoblar")),
      body: Container(
        decoration: appBackground,
        child: SafeArea(
          child: FutureBuilder<List<Book>>(
            future: BookService.instance.builtInBooks(),
            builder: (context, builtSnap) {
              return StreamBuilder<List<Book>>(
                stream: BookService.instance.customBooks(),
                builder: (context, customSnap) {
                  final built = builtSnap.data ?? const <Book>[];
                  final custom = customSnap.data ?? const <Book>[];
                  return ListView(
                    padding: const EdgeInsets.fromLTRB(18, 8, 18, 24),
                    children: [
                      for (var i = 0; i < built.length; i++)
                        FadeSlideIn(
                            index: i, child: _bookCard(context, built[i])),
                      if (custom.isNotEmpty)
                        const Padding(
                          padding: EdgeInsets.only(top: 8, bottom: 12),
                          child: Text("Mening kitoblarim",
                              style: TextStyle(
                                  color: AppColors.goldLight,
                                  fontWeight: FontWeight.w700)),
                        ),
                      for (final b in custom) _bookCard(context, b),
                      if (customSnap.hasError)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 14),
                          child: Text(
                            "Shaxsiy kitoblar yuklanmadi: ${friendlyError(customSnap.error!)}",
                            style: const TextStyle(color: Colors.redAccent),
                          ),
                        ),
                      const SizedBox(height: 6),
                      PressScale(
                        onTap: () => _addBook(context),
                        child: Container(
                          height: 56,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(18),
                            border: Border.all(color: AppColors.gold),
                          ),
                          child: const Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.add_rounded, color: AppColors.gold),
                              SizedBox(width: 8),
                              Text("Kitob qo'shish",
                                  style: TextStyle(
                                      color: AppColors.gold,
                                      fontWeight: FontWeight.w700,
                                      fontSize: 16)),
                            ],
                          ),
                        ),
                      ),
                    ],
                  );
                },
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _bookCard(BuildContext context, Book b) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: PressScale(
        onTap: () => _open(context, b),
        child: Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: AppColors.navy,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: AppColors.goldBorder),
          ),
          child: Row(
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  color: AppColors.navyLight,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: const Icon(Icons.menu_book_rounded,
                    color: AppColors.gold, size: 28),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(b.title,
                        style: const TextStyle(
                            fontSize: 17, fontWeight: FontWeight.w700)),
                    if (b.description.isNotEmpty) ...[
                      const SizedBox(height: 3),
                      Text(b.description,
                          style: const TextStyle(
                              color: AppColors.textDim, fontSize: 13)),
                    ],
                    const SizedBox(height: 6),
                    Text("${b.topics.length} ta mavzu",
                        style: const TextStyle(
                            color: AppColors.gold, fontSize: 13)),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right_rounded,
                  color: AppColors.textDim),
            ],
          ),
        ),
      ),
    );
  }
}
