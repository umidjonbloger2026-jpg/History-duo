import 'package:flutter/material.dart';
import '../core/theme.dart';

class SetupErrorScreen extends StatelessWidget {
  final String message;
  const SetupErrorScreen({super.key, required this.message});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: appBackground,
        padding: const EdgeInsets.all(28),
        child: SafeArea(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.build_circle_rounded,
                  size: 72, color: AppColors.gold),
              const SizedBox(height: 20),
              const Text('Firebase sozlanmagan',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
              const SizedBox(height: 12),
              Text(message,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: AppColors.textDim)),
            ],
          ),
        ),
      ),
    );
  }
}
