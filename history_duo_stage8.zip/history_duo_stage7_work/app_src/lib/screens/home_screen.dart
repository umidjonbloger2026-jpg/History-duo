import 'package:flutter/material.dart';
import '../core/theme.dart';
import '../widgets/animated_helpers.dart';
import '../widgets/logo.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'books_screen.dart';
import 'coming_soon_screen.dart';
import 'friend_screen.dart';
import 'match_flow.dart';
import 'waiting_screen.dart';
import '../models/book.dart';
import 'profile_screen.dart';
import 'results_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  void _open(BuildContext context, String title, IconData icon, int stage) {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => ComingSoonScreen(title: title, icon: icon, stage: stage),
    ));
  }

  Future<void> _findPartner(BuildContext context) async {
    if (await resumeActiveRoom(context)) return;
    if (!context.mounted) return;
    final sel = await Navigator.of(context).push<TopicSelection>(
        MaterialPageRoute(builder: (_) => const BooksScreen(pickMode: true)));
    if (sel == null || !context.mounted) return;
    Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => WaitingScreen(selection: sel)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: appBackground,
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(20, 24, 20, 24),
            child: Column(
              children: [
                const FadeSlideIn(index: 0, child: HistoryDuoLogo(size: 100)),
                const SizedBox(height: 10),
                const FadeSlideIn(
                  index: 1,
                  child: Text(
                    "Sherigingiz bilan birga tarixni ovozda o'rganing",
                    textAlign: TextAlign.center,
                    style: TextStyle(color: AppColors.textDim, fontSize: 14),
                  ),
                ),
                const SizedBox(height: 16),
                FadeSlideIn(
                  index: 2,
                  child: StreamBuilder<User?>(
                    stream: FirebaseAuth.instance.userChanges(),
                    builder: (context, snap) {
                      final n = snap.data?.displayName;
                      return Text(
                        "Salom, ${(n == null || n.isEmpty) ? "do'st" : n}!",
                        style: const TextStyle(
                            color: AppColors.goldLight,
                            fontSize: 18,
                            fontWeight: FontWeight.w700),
                      );
                    },
                  ),
                ),
                const SizedBox(height: 16),
                FadeSlideIn(
                  index: 2,
                  child: PressScale(
                    onTap: () => _findPartner(context),
                    child: Container(
                      height: 68,
                      width: double.infinity,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(22),
                        gradient: const LinearGradient(
                          colors: [AppColors.goldLight, AppColors.gold],
                        ),
                        boxShadow: const [
                          BoxShadow(
                            color: Color(0x55D4AF37),
                            blurRadius: 22,
                            offset: Offset(0, 8),
                          ),
                        ],
                      ),
                      child: const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.search_rounded,
                              color: AppColors.black, size: 28),
                          SizedBox(width: 10),
                          Text(
                            'Sherik topish',
                            style: TextStyle(
                              color: AppColors.black,
                              fontSize: 19,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 18),
                GridView.count(
                  crossAxisCount: 2,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  mainAxisSpacing: 14,
                  crossAxisSpacing: 14,
                  childAspectRatio: 1.05,
                  children: [
                    _menu(context, 3, "Do'st bilan ulanish",
                        Icons.group_add_rounded, 4,
                        onTap: () => Navigator.of(context).push(
                            MaterialPageRoute(
                                builder: (_) => const FriendScreen()))),
                    _menu(context, 4, 'Kitoblar', Icons.menu_book_rounded, 3,
                        onTap: () => Navigator.of(context).push(
                            MaterialPageRoute(
                                builder: (_) => const BooksScreen()))),
                    _menu(context, 5, 'Mening natijalarim',
                        Icons.emoji_events_rounded, 7,
                        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ResultsScreen()))),
                    _menu(context, 6, 'Profil va sozlamalar',
                        Icons.settings_rounded, 2,
                        onTap: () => Navigator.of(context).push(
                            MaterialPageRoute(
                                builder: (_) => const ProfileScreen()))),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _menu(
      BuildContext context, int index, String title, IconData icon, int stage,
      {VoidCallback? onTap}) {
    return FadeSlideIn(
      index: index,
      child: PressScale(
        onTap: onTap ?? () => _open(context, title, icon, stage),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            color: AppColors.navy,
            border: Border.all(color: AppColors.goldBorder),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 38, color: AppColors.gold),
              const SizedBox(height: 12),
              Text(
                title,
                textAlign: TextAlign.center,
                style: const TextStyle(
                    fontSize: 15, fontWeight: FontWeight.w600),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
