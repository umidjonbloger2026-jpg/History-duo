import 'package:flutter/material.dart';
import '../core/theme.dart';
import '../models/book.dart';
import '../services/auth_service.dart';
import '../services/match_service.dart';
import '../widgets/animated_helpers.dart';
import 'books_screen.dart';
import 'invite_host_screen.dart';
import 'match_flow.dart';
import 'room_screen.dart';

class FriendScreen extends StatefulWidget {
  const FriendScreen({super.key});

  @override
  State<FriendScreen> createState() => _FriendScreenState();
}

class _FriendScreenState extends State<FriendScreen> {
  bool _busy = false;

  void _snack(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<TopicSelection?> _pickTopic() {
    return Navigator.of(context).push<TopicSelection>(
        MaterialPageRoute(builder: (_) => const BooksScreen(pickMode: true)));
  }

  Future<void> _create() async {
    if (await resumeActiveRoom(context)) return;
    if (!mounted) return;
    final sel = await _pickTopic();
    if (sel == null || !mounted) return;
    Navigator.of(context).pushReplacement(MaterialPageRoute(
        builder: (_) => InviteHostScreen(selection: sel)));
  }

  Future<String?> _askCode() async {
    final c = TextEditingController();
    final res = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.navy,
        title: const Text("Kodni kiriting"),
        content: TextField(
          controller: c,
          autofocus: true,
          maxLength: 6,
          textCapitalization: TextCapitalization.characters,
          style: const TextStyle(letterSpacing: 6, fontSize: 22),
          decoration: const InputDecoration(hintText: "ABC123"),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text("Bekor qilish")),
          TextButton(
              onPressed: () => Navigator.pop(ctx, c.text.trim().toUpperCase()),
              child: const Text("Davom etish")),
        ],
      ),
    );
    return res;
  }

  Future<void> _join() async {
    if (await resumeActiveRoom(context)) return;
    if (!mounted) return;
    final code = await _askCode();
    if (code == null) return;
    if (code.length != 6) {
      _snack("Kod 6 ta belgidan iborat bo'lishi kerak");
      return;
    }
    if (!mounted) return;
    final sel = await _pickTopic();
    if (sel == null || !mounted) return;
    setState(() => _busy = true);
    try {
      final roomId = await MatchService.instance.joinInvite(code, sel);
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => RoomScreen(roomId: roomId)));
    } catch (e) {
      if (mounted) {
        setState(() => _busy = false);
        _snack(friendlyError(e));
      }
    }
  }

  Widget _card(IconData icon, String title, String sub, VoidCallback onTap) {
    return PressScale(
      onTap: _busy ? () {} : onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(20),
        margin: const EdgeInsets.only(bottom: 16),
        decoration: BoxDecoration(
          color: AppColors.navy,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: AppColors.goldBorder),
        ),
        child: Row(
          children: [
            Icon(icon, size: 40, color: AppColors.gold),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      style: const TextStyle(
                          fontSize: 17, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 4),
                  Text(sub,
                      style: const TextStyle(
                          color: AppColors.textDim, fontSize: 13)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Do'st bilan ulanish")),
      body: Container(
        decoration: appBackground,
        child: SafeArea(
          child: Stack(
            children: [
              ListView(
                padding: const EdgeInsets.all(20),
                children: [
                  _card(Icons.add_link_rounded, "Xona yaratish",
                      "Kod hosil qiling va do'stingizga yuboring", _create),
                  _card(Icons.keyboard_rounded, "Kodni kiritish",
                      "Do'stingiz yuborgan kod bilan ulaning", _join),
                  const Padding(
                    padding: EdgeInsets.all(8),
                    child: Text(
                      "Xavfsizlik uchun faqat bir xil yosh guruhidagi foydalanuvchilar ulana oladi.",
                      style: TextStyle(color: AppColors.textDim, fontSize: 13),
                    ),
                  ),
                ],
              ),
              if (_busy)
                const Center(
                    child: CircularProgressIndicator(color: AppColors.gold)),
            ],
          ),
        ),
      ),
    );
  }
}
