import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../core/theme.dart';
import '../models/book.dart';
import '../services/auth_service.dart';
import '../services/match_service.dart';
import '../widgets/animated_helpers.dart';
import '../widgets/pulse_radar.dart';
import 'room_screen.dart';

class WaitingScreen extends StatefulWidget {
  final TopicSelection selection;
  const WaitingScreen({super.key, required this.selection});

  @override
  State<WaitingScreen> createState() => _WaitingScreenState();
}

class _WaitingScreenState extends State<WaitingScreen> {
  Timer? _timer;
  StreamSubscription<DocumentSnapshot<Map<String, dynamic>>>? _sub;
  int _sec = 0;
  bool _busy = false;
  bool _matched = false;
  bool _offline = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _start();
  }

  Future<void> _start() async {
    try {
      await MatchService.instance.joinQueue(widget.selection);
    } catch (e) {
      if (mounted) {
        setState(() {
          _error = friendlyError(e);
          _offline = e is TimeoutException;
        });
      }
      return;
    }
    if (!mounted) {
      MatchService.instance.leaveQueue();
      return;
    }
    _sub = MatchService.instance.queueStream().listen((snap) {
      final r = snap.data()?['roomId'];
      if (r != null) _enterRoom(r as String);
    }, onError: (_) {});
    _tick();
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      setState(() => _sec++);
      if (_sec % 4 == 0) _tick();
    });
  }

  Future<void> _tick() async {
    if (_busy || _matched) return;
    _busy = true;
    try {
      await MatchService.instance.heartbeat();
      final roomId = await MatchService.instance.findAndMatch();
      if (mounted && (_offline || _error != null)) {
        setState(() {
          _offline = false;
          _error = null;
        });
      }
      if (roomId != null) _enterRoom(roomId);
    } catch (e) {
      if (mounted) {
        setState(() {
          _offline = e is TimeoutException ||
              (e is FirebaseException && e.code == 'unavailable');
          _error = friendlyError(e);
        });
      }
    } finally {
      _busy = false;
    }
  }

  void _enterRoom(String roomId) {
    if (_matched) return;
    _matched = true;
    _timer?.cancel();
    _sub?.cancel();
    MatchService.instance.leaveQueue();
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => RoomScreen(roomId: roomId)));
  }

  @override
  void dispose() {
    _timer?.cancel();
    _sub?.cancel();
    if (!_matched) MatchService.instance.leaveQueue();
    super.dispose();
  }

  String get _time {
    final m = (_sec ~/ 60).toString().padLeft(2, '0');
    final s = (_sec % 60).toString().padLeft(2, '0');
    return "$m:$s";
  }

  @override
  Widget build(BuildContext context) {
    final sel = widget.selection;
    return Scaffold(
      appBar: AppBar(title: const Text("Sherik qidirilmoqda")),
      body: Container(
        decoration: appBackground,
        width: double.infinity,
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(22),
            child: Column(
              children: [
                if (_offline)
                  Container(
                    width: double.infinity,
                    margin: const EdgeInsets.only(bottom: 12),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: const Color(0x33FF5252),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: const Row(
                      children: [
                        Icon(Icons.wifi_off_rounded, color: Colors.redAccent),
                        SizedBox(width: 10),
                        Expanded(
                            child: Text(
                                "Internet aloqasi yo'q. Ulanish tiklanishi bilan qidiruv davom etadi.")),
                      ],
                    ),
                  ),
                const Spacer(),
                const PulseRadar(),
                const SizedBox(height: 24),
                Text(_time,
                    style: const TextStyle(
                        fontSize: 34,
                        fontWeight: FontWeight.w800,
                        color: AppColors.gold)),
                const SizedBox(height: 8),
                const Text("Onlayn sherik qidirilmoqda...",
                    style: TextStyle(fontSize: 17)),
                if (_sec >= 60)
                  const Padding(
                    padding: EdgeInsets.only(top: 10),
                    child: Text(
                      "Hozircha onlayn foydalanuvchi kam. Kutishda davom etishingiz yoki keyinroq urinib ko'rishingiz mumkin.",
                      textAlign: TextAlign.center,
                      style: TextStyle(color: AppColors.textDim),
                    ),
                  ),
                if (_error != null && !_offline)
                  Padding(
                    padding: const EdgeInsets.only(top: 10),
                    child: Text(_error!,
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: Colors.redAccent)),
                  ),
                const Spacer(),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppColors.navy,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: AppColors.goldBorder),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text("Tanlangan mavzu",
                          style: TextStyle(
                              color: AppColors.textDim, fontSize: 12)),
                      const SizedBox(height: 4),
                      Text(sel.book.title,
                          style: const TextStyle(fontWeight: FontWeight.w700)),
                      Text(sel.topic.title,
                          style: const TextStyle(color: AppColors.goldLight)),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                PressScale(
                  onTap: () => Navigator.of(context).pop(),
                  child: Container(
                    height: 54,
                    width: double.infinity,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: Colors.redAccent),
                    ),
                    child: const Text("Qidiruvni bekor qilish",
                        style: TextStyle(
                            color: Colors.redAccent,
                            fontWeight: FontWeight.w700)),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
