import 'package:flutter/material.dart';
import '../core/theme.dart';
import '../services/auth_service.dart';
import '../widgets/animated_helpers.dart';
import '../widgets/logo.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _pass = TextEditingController();

  bool _isLogin = true;
  bool _hide = true;
  bool _accepted = false;
  bool _loading = false;
  String _ageGroup = 'adult';
  String? _error;

  @override
  void dispose() {
    _name.dispose();
    _email.dispose();
    _pass.dispose();
    super.dispose();
  }

  InputDecoration _dec(String label, IconData icon, {Widget? suffix}) {
    return InputDecoration(
      labelText: label,
      prefixIcon: Icon(icon, color: AppColors.gold),
      suffixIcon: suffix,
      filled: true,
      fillColor: AppColors.navy,
      labelStyle: const TextStyle(color: AppColors.textDim),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: const BorderSide(color: AppColors.goldBorder),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: const BorderSide(color: AppColors.gold, width: 1.5),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: const BorderSide(color: Colors.redAccent),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: const BorderSide(color: Colors.redAccent, width: 1.5),
      ),
    );
  }

  Future<void> _submit() async {
    FocusScope.of(context).unfocus();
    if (!_formKey.currentState!.validate()) return;
    if (!_isLogin && !_accepted) {
      setState(() => _error = "Davom etish uchun qoidalarga rozilik bering");
      return;
    }
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      if (_isLogin) {
        await AuthService.instance
            .signIn(email: _email.text.trim(), password: _pass.text);
      } else {
        await AuthService.instance.signUp(
          name: _name.text.trim(),
          email: _email.text.trim(),
          password: _pass.text,
          ageGroup: _ageGroup,
        );
      }
    } catch (e) {
      if (mounted) setState(() => _error = friendlyError(e));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _reset() async {
    final email = _email.text.trim();
    if (!email.contains('@')) {
      setState(() => _error = "Avval email manzilingizni kiriting");
      return;
    }
    try {
      await AuthService.instance.resetPassword(email);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text("Parolni tiklash havolasi emailingizga yuborildi")));
    } catch (e) {
      if (mounted) setState(() => _error = friendlyError(e));
    }
  }

  void _showRules() {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.navy,
        title: const Text("Xavfsiz foydalanish qoidalari"),
        content: const SingleChildScrollView(
          child: Text(
            "• Telefon raqami, manzil va boshqa shaxsiy ma'lumotlarni aytmang.\n"
            "• Sherigingizga hurmat bilan munosabatda bo'ling.\n"
            "• Haqorat, tahdid va nomaqbul gaplar taqiqlanadi.\n"
            "• Noqulay holatda suhbatni istalgan vaqtda tugating, "
            "foydalanuvchini bloklang yoki shikoyat qiling.\n"
            "• 13–17 yoshli foydalanuvchilar faqat o'z yosh guruhi bilan ulanadi.\n"
            "• 13 yoshdan kichiklar ilovadan foydalana olmaydi.",
            style: TextStyle(height: 1.4),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text("Yopish"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: appBackground,
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(22, 20, 22, 24),
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  const FadeSlideIn(index: 0, child: HistoryDuoLogo(size: 80)),
                  const SizedBox(height: 24),
                  Text(
                    _isLogin ? "Kirish" : "Ro'yxatdan o'tish",
                    style: const TextStyle(
                        fontSize: 24, fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 20),
                  AnimatedSize(
                    duration: const Duration(milliseconds: 250),
                    curve: Curves.easeOut,
                    child: _isLogin
                        ? const SizedBox(width: double.infinity)
                        : Column(
                            children: [
                              TextFormField(
                                controller: _name,
                                textCapitalization: TextCapitalization.words,
                                decoration:
                                    _dec("Ismingiz", Icons.person_rounded),
                                validator: (v) {
                                  final s = (v ?? '').trim();
                                  if (s.length < 2) return "Kamida 2 ta harf";
                                  if (s.length > 24) return "Ko'pi bilan 24 ta";
                                  return null;
                                },
                              ),
                              const SizedBox(height: 14),
                            ],
                          ),
                  ),
                  TextFormField(
                    controller: _email,
                    keyboardType: TextInputType.emailAddress,
                    decoration: _dec("Email", Icons.email_rounded),
                    validator: (v) {
                      final s = (v ?? '').trim();
                      if (!s.contains('@') || !s.contains('.')) {
                        return "To'g'ri email kiriting";
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 14),
                  TextFormField(
                    controller: _pass,
                    obscureText: _hide,
                    decoration: _dec(
                      "Parol",
                      Icons.lock_rounded,
                      suffix: IconButton(
                        icon: Icon(
                          _hide
                              ? Icons.visibility_rounded
                              : Icons.visibility_off_rounded,
                          color: AppColors.textDim,
                        ),
                        onPressed: () => setState(() => _hide = !_hide),
                      ),
                    ),
                    validator: (v) => (v ?? '').length < 8
                        ? "Kamida 8 ta belgi"
                        : null,
                  ),
                  if (_isLogin)
                    Align(
                      alignment: Alignment.centerRight,
                      child: TextButton(
                        onPressed: _reset,
                        child: const Text("Parolni unutdingizmi?",
                            style: TextStyle(color: AppColors.goldLight)),
                      ),
                    ),
                  if (!_isLogin) ...[
                    const SizedBox(height: 16),
                    const Align(
                      alignment: Alignment.centerLeft,
                      child: Text("Yosh guruhingiz",
                          style: TextStyle(color: AppColors.textDim)),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        _ageChip('adult', "18 va undan katta"),
                        const SizedBox(width: 10),
                        _ageChip('teen', "13–17 yosh"),
                      ],
                    ),
                    const SizedBox(height: 6),
                    CheckboxListTile(
                      value: _accepted,
                      onChanged: (v) => setState(() => _accepted = v ?? false),
                      activeColor: AppColors.gold,
                      checkColor: AppColors.black,
                      contentPadding: EdgeInsets.zero,
                      controlAffinity: ListTileControlAffinity.leading,
                      title: GestureDetector(
                        onTap: _showRules,
                        child: const Text(
                          "Xavfsiz foydalanish qoidalariga roziman (o'qish)",
                          style: TextStyle(
                              fontSize: 13,
                              color: AppColors.goldLight,
                              decoration: TextDecoration.underline),
                        ),
                      ),
                    ),
                  ],
                  if (_error != null) ...[
                    const SizedBox(height: 8),
                    Text(_error!,
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: Colors.redAccent)),
                  ],
                  const SizedBox(height: 18),
                  PressScale(
                    onTap: _loading ? () {} : _submit,
                    child: Container(
                      height: 58,
                      width: double.infinity,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(18),
                        gradient: const LinearGradient(
                            colors: [AppColors.goldLight, AppColors.gold]),
                      ),
                      child: _loading
                          ? const SizedBox(
                              width: 24,
                              height: 24,
                              child: CircularProgressIndicator(
                                  strokeWidth: 3, color: AppColors.black))
                          : Text(
                              _isLogin ? "Kirish" : "Ro'yxatdan o'tish",
                              style: const TextStyle(
                                  color: AppColors.black,
                                  fontSize: 17,
                                  fontWeight: FontWeight.w800),
                            ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  TextButton(
                    onPressed: _loading
                        ? null
                        : () => setState(() {
                              _isLogin = !_isLogin;
                              _error = null;
                            }),
                    child: Text(
                      _isLogin
                          ? "Hisobingiz yo'qmi? Ro'yxatdan o'ting"
                          : "Hisobingiz bormi? Kirish",
                      style: const TextStyle(color: AppColors.goldLight),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _ageChip(String value, String label) {
    final selected = _ageGroup == value;
    return ChoiceChip(
      label: Text(label),
      selected: selected,
      onSelected: (_) => setState(() => _ageGroup = value),
      selectedColor: AppColors.gold,
      backgroundColor: AppColors.navy,
      showCheckmark: false,
      side: const BorderSide(color: AppColors.goldBorder),
      labelStyle: TextStyle(
        color: selected ? AppColors.black : AppColors.textMain,
        fontWeight: FontWeight.w600,
      ),
    );
  }
}
