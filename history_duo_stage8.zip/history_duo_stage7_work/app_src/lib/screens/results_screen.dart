import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../core/theme.dart';

class ResultsScreen extends StatelessWidget {
  const ResultsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return const Scaffold(body: Center(child: Text('Avval tizimga kiring.')));
    final sessions = FirebaseFirestore.instance
        .collection('users').doc(uid).collection('sessions')
        .orderBy('completedAt', descending: true).limit(50);
    return Scaffold(
      appBar: AppBar(title: const Text('Mening natijalarim')),
      body: Container(
        decoration: appBackground,
        child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: sessions.snapshots(),
          builder: (context, snap) {
            if (snap.hasError) return const Center(child: Text('Natijalarni yuklab bo‘lmadi.'));
            if (!snap.hasData) return const Center(child: CircularProgressIndicator(color: AppColors.gold));
            final docs = snap.data!.docs;
            final total = docs.length;
            final earned = docs.fold<int>(0, (sum, d) => sum + ((d.data()['myScore'] as num?)?.toInt() ?? 0));
            final possible = docs.fold<int>(0, (sum, d) => sum + ((d.data()['sectionCount'] as num?)?.toInt() ?? 0));
            return ListView(
              padding: const EdgeInsets.all(18),
              children: [
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(color: AppColors.navy, borderRadius: BorderRadius.circular(20), border: Border.all(color: AppColors.goldBorder)),
                  child: Row(children: [
                    _stat('Mashg‘ulot', '$total'), const SizedBox(width: 12),
                    _stat('Ball', '$earned'), const SizedBox(width: 12),
                    _stat('Imkoniyat', '$possible'),
                  ]),
                ),
                const SizedBox(height: 18),
                const Text('Oxirgi mashg‘ulotlar', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                const SizedBox(height: 10),
                if (docs.isEmpty)
                  const Padding(padding: EdgeInsets.only(top: 45), child: Column(children: [Icon(Icons.menu_book_rounded, size: 48, color: AppColors.gold), SizedBox(height: 12), Text('Hali yakunlangan mashg‘ulot yo‘q.'), Text('Sherik bilan tarix o‘rganishni boshlang.', style: TextStyle(color: AppColors.textDim))]))
                else ...docs.map((doc) {
                  final d = doc.data();
                  final score = (d['myScore'] as num?)?.toInt() ?? 0;
                  final count = (d['sectionCount'] as num?)?.toInt() ?? 0;
                  final when = (d['completedAt'] as Timestamp?)?.toDate();
                  final date = when == null ? 'Sana noma’lum' : '${when.day.toString().padLeft(2,'0')}.${when.month.toString().padLeft(2,'0')}.${when.year}';
                  return Container(
                    margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(15),
                    decoration: BoxDecoration(color: AppColors.navy, borderRadius: BorderRadius.circular(17), border: Border.all(color: AppColors.goldBorder)),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text((d['topicTitle'] ?? 'Tarix mavzusi').toString(), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                      const SizedBox(height: 4), Text((d['bookTitle'] ?? '').toString(), style: const TextStyle(color: AppColors.textDim)),
                      const SizedBox(height: 10), Row(children: [const Icon(Icons.person_outline, size: 17, color: AppColors.gold), const SizedBox(width: 5), Expanded(child: Text('Sherik: ${(d['partnerName'] ?? 'Foydalanuvchi').toString()}')), Text('$score/$count', style: const TextStyle(color: AppColors.gold, fontWeight: FontWeight.w900))]),
                      const SizedBox(height: 5), Text(date, style: const TextStyle(color: AppColors.textDim, fontSize: 12)),
                    ]),
                  );
                }),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _stat(String label, String value) => Expanded(child: Column(children: [Text(value, style: const TextStyle(color: AppColors.gold, fontSize: 23, fontWeight: FontWeight.w900)), const SizedBox(height: 3), Text(label, textAlign: TextAlign.center, style: const TextStyle(color: AppColors.textDim, fontSize: 11))]));
}
