import 'package:flutter/material.dart';
import '../core/theme.dart';
import '../models/book.dart';
import '../services/auth_service.dart';
import '../services/book_service.dart';
import '../widgets/animated_helpers.dart';

/// Shaxsiy kitobga mavzu qo'shish. Bo'limlar bo'sh qator bilan ajratiladi.
class AddTopicScreen extends StatefulWidget {
  final Book book;
  const AddTopicScreen({super.key, required this.book});

  @override
  State<AddTopicScreen> createState() => _AddTopicScreenState();
}

class _AddTopicScreenState extends State<AddTopicScreen> {
  static const maxSectionChars = 1500;
  final _title = TextEditingController();
  final _body = TextEditingController();
  bool _saving = false;
  String? _error;

  @override
  void dispose() {
    _title.dispose();
    _body.dispose();
    super.dispose();
  }

  List<String> _parse(String raw) {
    return raw
        .replaceAll('\r', '')
        .split(RegExp(r'\n\s*\n'))
        .map((s) => s.trim())
        .where((s) => s.isNotEmpty)
        .toList();
  }

  Future<void> _save() async {
    FocusScope.of(context).unfocus();
    final title = _title.text.trim();
    final parts = _parse(_body.text);
    String? err;
    if (title.length < 2 || title.length > 60) {
      err = "Mavzu nomi 2–60 ta belgi bo'lsin";
    } else if (parts.isEmpty) {
      err = "Matn kiriting";
    } else if (parts.length > 30) {
      err = "Bo'limlar soni 30 tadan oshmasin";
    } else {
      for (var i = 0; i < parts.length; i++) {
        if (parts[i].length > maxSectionChars) {
          err =
              "${i + 1}-bo'lim juda uzun (${parts[i].length} belgi). Eng ko'pi $maxSectionChars. Uni bo'sh qator bilan ikkiga bo'ling.";
          break;
        }
      }
    }
    if (err != null) {
      setState(() => _error = err);
      return;
    }
    setState(() {
      _saving = true;
      _error = null;
    });
    final topic = Topic(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      title: title,
      sections: [
        for (var i = 0; i < parts.length; i++)
          Section(title: "${i + 1}-bo'lim", text: parts[i]),
      ],
    );
    try {
      await BookService.instance.addTopic(widget.book, topic);
      if (mounted) Navigator.of(context).pop();
    } catch (e) {
      if (mounted) {
        setState(() {
          _error = friendlyError(e);
          _saving = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final count = _parse(_body.text).length;
    return Scaffold(
      appBar: AppBar(title: const Text("Mavzu qo'shish")),
      body: Container(
        decoration: appBackground,
        child: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(18),
            children: [
              Text("Kitob: ${widget.book.title}",
                  style: const TextStyle(color: AppColors.textDim)),
              const SizedBox(height: 14),
              TextField(
                controller: _title,
                maxLength: 60,
                decoration: _dec("Mavzu nomi"),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: _body,
                minLines: 10,
                maxLines: 20,
                keyboardType: TextInputType.multiline,
                onChanged: (_) => setState(() {}),
                decoration: _dec("Matn").copyWith(
                  alignLabelWithHint: true,
                  helperText:
                      "Bo'limlarni bo'sh qator bilan ajrating. Har bir bo'lim eng ko'pi $maxSectionChars belgi.",
                  helperMaxLines: 3,
                ),
              ),
              const SizedBox(height: 8),
              Text("Bo'limlar soni: $count",
                  style: const TextStyle(color: AppColors.gold)),
              if (_error != null) ...[
                const SizedBox(height: 10),
                Text(_error!, style: const TextStyle(color: Colors.redAccent)),
              ],
              const SizedBox(height: 18),
              PressScale(
                onTap: _saving ? () {} : _save,
                child: Container(
                  height: 56,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(18),
                    gradient: const LinearGradient(
                        colors: [AppColors.goldLight, AppColors.gold]),
                  ),
                  child: _saving
                      ? const SizedBox(
                          width: 24,
                          height: 24,
                          child: CircularProgressIndicator(
                              strokeWidth: 3, color: AppColors.black))
                      : const Text("Saqlash",
                          style: TextStyle(
                              color: AppColors.black,
                              fontSize: 17,
                              fontWeight: FontWeight.w800)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  InputDecoration _dec(String label) {
    return InputDecoration(
      labelText: label,
      filled: true,
      fillColor: AppColors.navy,
      labelStyle: const TextStyle(color: AppColors.textDim),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: const BorderSide(color: AppColors.goldBorder),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(16),
        borderSide: const BorderSide(color: AppColors.gold, width: 1.5),
      ),
    );
  }
}
