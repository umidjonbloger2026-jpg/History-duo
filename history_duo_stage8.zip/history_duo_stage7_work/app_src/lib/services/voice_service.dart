import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:permission_handler/permission_handler.dart';

import '../ice_config.dart';

enum VoiceStatus {
  idle,
  requesting,
  micDenied,
  connecting,
  connected,
  unstable,
  failed,
}

/// Faqat audio WebRTC. Signalizatsiya: rooms/{id}/signals/offer_N, answer_N.
/// Trickle ICE ishlatilmaydi: nomzodlar yig'ilgach bitta hujjat yoziladi
/// (Firestore bepul limitini tejash uchun).
class VoiceService extends ChangeNotifier {
  VoiceService({required this.roomId, required this.isCaller});

  final String roomId;
  final bool isCaller;

  VoiceStatus status = VoiceStatus.idle;
  String? error;
  bool micOn = true;
  bool speakerOn = true;
  double volume = 1.0; // 0.0 - 2.0
  int attempt = -1;

  RTCPeerConnection? _pc;
  MediaStream? _local;
  MediaStreamTrack? _remoteTrack;
  StreamSubscription<DocumentSnapshot<Map<String, dynamic>>>? _sigSub;
  Timer? _unstableTimer;
  bool _disposed = false;
  bool _handled = false;
  final List<String> _written = [];

  String get _uid => FirebaseAuth.instance.currentUser!.uid;
  CollectionReference<Map<String, dynamic>> get _signals => FirebaseFirestore
      .instance
      .collection('rooms')
      .doc(roomId)
      .collection('signals');

  bool _stale(int a) => _disposed || a != attempt;

  void _set(VoiceStatus s, [String? err]) {
    status = s;
    error = err;
    if (!_disposed) notifyListeners();
  }

  // ---------- ICE serverlar ----------

  Future<List<Map<String, dynamic>>> _iceServers() async {
    final servers = <Map<String, dynamic>>[
      {
        'urls': [
          'stun:stun.l.google.com:19302',
          'stun:stun1.l.google.com:19302',
        ]
      }
    ];
    if (IceConfig.meteredApp.isNotEmpty && IceConfig.meteredKey.isNotEmpty) {
      final client = HttpClient();
      try {
        final uri = Uri.parse(
            'https://${IceConfig.meteredApp}.metered.live/api/v1/turn/credentials?apiKey=${IceConfig.meteredKey}');
        final req = await client.getUrl(uri).timeout(const Duration(seconds: 6));
        final res = await req.close().timeout(const Duration(seconds: 6));
        final body = await res.transform(utf8.decoder).join();
        final list = json.decode(body) as List;
        for (final e in list) {
          servers.add(Map<String, dynamic>.from(e as Map));
        }
      } catch (_) {
        // TURN olinmasa, faqat STUN bilan davom etamiz
      } finally {
        client.close();
      }
    }
    if (IceConfig.turnUrl.isNotEmpty) {
      servers.add({
        'urls': IceConfig.turnUrl,
        'username': IceConfig.turnUsername,
        'credential': IceConfig.turnCredential,
      });
    }
    return servers;
  }

  // ---------- boshlash / qayta boshlash ----------

  Future<void> start(int newAttempt) async {
    if (_disposed) return;
    attempt = newAttempt;
    final a = newAttempt;
    await _teardown();
    _handled = false;
    _set(VoiceStatus.requesting);

    final perm = await Permission.microphone.request();
    if (_stale(a)) return;
    if (!perm.isGranted) {
      _set(VoiceStatus.micDenied);
      return;
    }

    _set(VoiceStatus.connecting);
    try {
      final ice = await _iceServers();
      if (_stale(a)) return;
      final pc = await createPeerConnection({
        'iceServers': ice,
        'sdpSemantics': 'unified-plan',
      });
      if (_stale(a)) {
        await pc.close();
        return;
      }
      _pc = pc;
      pc.onConnectionState = _onConn;
      pc.onTrack = (RTCTrackEvent e) {
        if (e.track.kind == 'audio') {
          _remoteTrack = e.track;
          _applyVolume();
        }
      };

      final local = await navigator.mediaDevices.getUserMedia({
        'audio': {
          'echoCancellation': true,
          'noiseSuppression': true,
          'autoGainControl': true,
        },
        'video': false,
      });
      if (_stale(a)) {
        for (final t in local.getTracks()) {
          t.stop();
        }
        return;
      }
      _local = local;
      for (final t in local.getAudioTracks()) {
        t.enabled = micOn;
        await pc.addTrack(t, local);
      }
      try {
        await Helper.setSpeakerphoneOn(speakerOn);
      } catch (_) {}

      if (isCaller) {
        await _callerFlow(pc, a);
      } else {
        _calleeListen(pc, a);
      }
    } catch (e) {
      if (!_stale(a)) _set(VoiceStatus.failed, '$e');
    }
  }

  Future<void> _setLocalAndGather(
      RTCPeerConnection pc, RTCSessionDescription desc) async {
    final gathered = Completer<void>();
    pc.onIceGatheringState = (RTCIceGatheringState s) {
      if (s == RTCIceGatheringState.RTCIceGatheringStateComplete &&
          !gathered.isCompleted) {
        gathered.complete();
      }
    };
    await pc.setLocalDescription(desc);
    await gathered.future.timeout(const Duration(seconds: 5), onTimeout: () {});
  }

  Future<void> _callerFlow(RTCPeerConnection pc, int a) async {
    final offer = await pc.createOffer({'offerToReceiveAudio': true});
    await _setLocalAndGather(pc, offer);
    if (_stale(a)) return;
    final desc = await pc.getLocalDescription();
    final id = 'offer_$a';
    await _signals.doc(id).set({
      'from': _uid,
      'attempt': a,
      'type': 'offer',
      'sdp': desc!.sdp,
      'createdAt': FieldValue.serverTimestamp(),
    });
    _written.add(id);
    _sigSub = _signals.doc('answer_$a').snapshots().listen((s) async {
      final d = s.data();
      if (d == null || _handled || d['from'] == _uid || _stale(a)) return;
      _handled = true;
      try {
        await pc.setRemoteDescription(
            RTCSessionDescription(d['sdp'] as String, 'answer'));
      } catch (e) {
        if (!_stale(a)) _set(VoiceStatus.failed, '$e');
      }
    });
  }

  void _calleeListen(RTCPeerConnection pc, int a) {
    _sigSub = _signals.doc('offer_$a').snapshots().listen((s) async {
      final d = s.data();
      if (d == null || _handled || d['from'] == _uid || _stale(a)) return;
      _handled = true;
      try {
        await pc.setRemoteDescription(
            RTCSessionDescription(d['sdp'] as String, 'offer'));
        final answer = await pc.createAnswer({'offerToReceiveAudio': true});
        await _setLocalAndGather(pc, answer);
        if (_stale(a)) return;
        final desc = await pc.getLocalDescription();
        final id = 'answer_$a';
        await _signals.doc(id).set({
          'from': _uid,
          'attempt': a,
          'type': 'answer',
          'sdp': desc!.sdp,
          'createdAt': FieldValue.serverTimestamp(),
        });
        _written.add(id);
      } catch (e) {
        if (!_stale(a)) _set(VoiceStatus.failed, '$e');
      }
    });
  }

  void _onConn(RTCPeerConnectionState s) {
    if (_disposed) return;
    switch (s) {
      case RTCPeerConnectionState.RTCPeerConnectionStateConnected:
        _unstableTimer?.cancel();
        _set(VoiceStatus.connected);
        break;
      case RTCPeerConnectionState.RTCPeerConnectionStateDisconnected:
        _set(VoiceStatus.unstable);
        _unstableTimer?.cancel();
        _unstableTimer = Timer(const Duration(seconds: 10), () {
          if (status == VoiceStatus.unstable) _set(VoiceStatus.failed);
        });
        break;
      case RTCPeerConnectionState.RTCPeerConnectionStateFailed:
        _unstableTimer?.cancel();
        _set(VoiceStatus.failed);
        break;
      default:
        break;
    }
  }

  // ---------- boshqaruv ----------

  void setMic(bool on) {
    micOn = on;
    for (final t in _local?.getAudioTracks() ?? <MediaStreamTrack>[]) {
      t.enabled = on;
    }
    if (!_disposed) notifyListeners();
  }

  Future<void> setSpeaker(bool on) async {
    speakerOn = on;
    try {
      await Helper.setSpeakerphoneOn(on);
    } catch (_) {}
    if (!_disposed) notifyListeners();
  }

  void setVolume(double v) {
    volume = v;
    _applyVolume();
    if (!_disposed) notifyListeners();
  }

  void _applyVolume() {
    final t = _remoteTrack;
    if (t == null) return;
    try {
      Helper.setVolume(volume, t);
    } catch (_) {}
  }

  // ---------- tozalash ----------

  Future<void> _teardown() async {
    _unstableTimer?.cancel();
    await _sigSub?.cancel();
    _sigSub = null;
    _remoteTrack = null;
    try {
      for (final t in _local?.getTracks() ?? <MediaStreamTrack>[]) {
        t.stop();
      }
      await _local?.dispose();
    } catch (_) {}
    _local = null;
    try {
      await _pc?.close();
    } catch (_) {}
    _pc = null;
  }

  @override
  void dispose() {
    _disposed = true;
    _teardown();
    for (final id in _written) {
      _signals.doc(id).delete().catchError((_) {});
    }
    super.dispose();
  }
}
