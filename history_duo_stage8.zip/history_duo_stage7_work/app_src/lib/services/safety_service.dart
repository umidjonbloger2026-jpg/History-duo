import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class SafetyService {
  SafetyService._();
  static final SafetyService instance = SafetyService._();
  final _db = FirebaseFirestore.instance;
  String get _uid => FirebaseAuth.instance.currentUser!.uid;

  Future<void> blockUser(String otherUid) async {
    if (otherUid == _uid) return;
    await _db.collection('users').doc(_uid).update({'blocked': FieldValue.arrayUnion([otherUid])});
  }

  Future<void> reportUser({required String otherUid, required String roomId, required String reason}) async {
    if (otherUid == _uid) return;
    await _db.collection('reports').add({
      'reporterUid': _uid,
      'reportedUid': otherUid,
      'roomId': roomId,
      'reason': reason,
      'createdAt': FieldValue.serverTimestamp(),
      'status': 'new',
    });
  }
}
