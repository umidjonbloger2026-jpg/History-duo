import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

/// Ikki kishilik o'rganish jarayonini Firestore orqali sinxron boshqaradi.
/// phase: reading -> reciting -> grading -> (next section / next round / completed)
class StudyRoundService {
  StudyRoundService._();
  static final StudyRoundService instance = StudyRoundService._();

  FirebaseFirestore get _db => FirebaseFirestore.instance;
  String get _uid => FirebaseAuth.instance.currentUser!.uid;
  DocumentReference<Map<String, dynamic>> _room(String id) =>
      _db.collection('rooms').doc(id);

  Future<void> markReadDone(String roomId) async {
    await _db.runTransaction((tx) async {
      final ref = _room(roomId);
      final snap = await tx.get(ref);
      final d = snap.data();
      if (d == null || d['status'] != 'active') return;
      if (d['readerUid'] != _uid || d['phase'] != 'reading') return;
      tx.update(ref, {
        'phase': 'reciting',
        'phaseUpdatedAt': FieldValue.serverTimestamp(),
      });
    });
  }

  Future<void> markRecited(String roomId) async {
    await _db.runTransaction((tx) async {
      final ref = _room(roomId);
      final snap = await tx.get(ref);
      final d = snap.data();
      if (d == null || d['status'] != 'active') return;
      final participants = List<String>.from(d['participants'] as List);
      final reader = d['readerUid'] as String;
      final listener = participants.firstWhere((p) => p != reader);
      if (_uid != listener || d['phase'] != 'reciting') return;
      tx.update(ref, {
        'phase': 'grading',
        'phaseUpdatedAt': FieldValue.serverTimestamp(),
      });
    });
  }

  /// Faqat shu rounddagi o'quvchi sherigining javobini baholaydi.
  Future<void> gradeAnswer(String roomId, {required bool correct}) async {
    await _db.runTransaction((tx) async {
      final ref = _room(roomId);
      final snap = await tx.get(ref);
      final d = snap.data();
      if (d == null || d['status'] != 'active') return;
      if (d['readerUid'] != _uid || d['phase'] != 'grading') return;

      final participants = List<String>.from(d['participants'] as List);
      final round = (d['round'] as num?)?.toInt() ?? 1;
      final index = (d['sectionIndex'] as num?)?.toInt() ?? 0;
      final pick = Map<String, dynamic>.from(d['sharedPick'] as Map);
      final sections = List<Map<String, dynamic>>.from(
        (pick['sections'] as List).map((e) => Map<String, dynamic>.from(e as Map)),
      );
      if (sections.isEmpty) return;
      final scores = Map<String, dynamic>.from((d['scores'] as Map?) ?? {});
      final listener = participants.firstWhere((p) => p != _uid);
      final oldScore = (scores[listener] as num?)?.toInt() ?? 0;
      if (correct) scores[listener] = oldScore + 1;

      final result = {
        'round': round,
        'sectionIndex': index,
        'readerUid': _uid,
        'listenerUid': listener,
        'correct': correct,
        'gradedAt': FieldValue.serverTimestamp(),
      };

      if (index + 1 < sections.length) {
        tx.update(ref, {
          'scores': scores,
          'lastResult': result,
          'sectionIndex': index + 1,
          'phase': 'reading',
          'phaseUpdatedAt': FieldValue.serverTimestamp(),
        });
      } else if (round == 1) {
        tx.update(ref, {
          'scores': scores,
          'lastResult': result,
          'round': 2,
          'sectionIndex': 0,
          'readerUid': participants[1],
          'phase': 'reading',
          'phaseUpdatedAt': FieldValue.serverTimestamp(),
        });
      } else {
        tx.update(ref, {
          'scores': scores,
          'lastResult': result,
          'phase': 'completed',
          'completedAt': FieldValue.serverTimestamp(),
          'phaseUpdatedAt': FieldValue.serverTimestamp(),
        });
      }
    });
  }
}
