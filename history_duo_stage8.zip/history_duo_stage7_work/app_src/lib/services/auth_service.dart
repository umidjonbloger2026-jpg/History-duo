import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../core/errors.dart';

class AuthService {
  AuthService._();
  static final AuthService instance = AuthService._();

  FirebaseAuth get _auth => FirebaseAuth.instance;
  FirebaseFirestore get _db => FirebaseFirestore.instance;

  User? get currentUser => _auth.currentUser;

  Future<void> signUp({
    required String name,
    required String email,
    required String password,
    required String ageGroup,
  }) async {
    final cred = await _auth.createUserWithEmailAndPassword(
        email: email, password: password);
    final user = cred.user!;
    try {
      await user.updateDisplayName(name);
      // Ommaviy hujjatda email saqlanmaydi (maxfiylik).
      await _db.collection('users').doc(user.uid).set({
        'displayName': name,
        'ageGroup': ageGroup, // 'adult' yoki 'teen'
        'currentRoomId': null,
        'blocked': <String>[],
        'createdAt': FieldValue.serverTimestamp(),
      });
      await user.reload();
    } catch (e) {
      await user.delete();
      rethrow;
    }
  }

  Future<void> signIn({required String email, required String password}) {
    return _auth.signInWithEmailAndPassword(email: email, password: password);
  }

  Future<void> resetPassword(String email) {
    return _auth.sendPasswordResetEmail(email: email);
  }

  Future<void> signOut() => _auth.signOut();

  Future<void> updateName(String name) async {
    final user = _auth.currentUser;
    if (user == null) return;
    await user.updateDisplayName(name);
    await _db.collection('users').doc(user.uid).update({'displayName': name});
  }

  /// Hisobni butunlay o'chirish (Google Play talabi).
  Future<void> deleteAccount(String password) async {
    final user = _auth.currentUser;
    if (user == null || user.email == null) return;
    final cred =
        EmailAuthProvider.credential(email: user.email!, password: password);
    await user.reauthenticateWithCredential(cred);
    final books =
        await _db.collection('users').doc(user.uid).collection('books').get();
    for (final d in books.docs) {
      await d.reference.delete();
    }
    await _db.collection('users').doc(user.uid).delete();
    await user.delete();
  }
}

String friendlyError(Object e) {
  if (e is UserFacingException) return e.message;
  if (e is TimeoutException) return "Internet aloqasi yo'q yoki juda sekin";
  if (e is FirebaseAuthException) {
    switch (e.code) {
      case 'invalid-email':
        return "Email manzili noto'g'ri";
      case 'user-not-found':
      case 'wrong-password':
      case 'invalid-credential':
        return "Email yoki parol noto'g'ri";
      case 'email-already-in-use':
        return "Bu email allaqachon ro'yxatdan o'tgan";
      case 'weak-password':
        return "Parol juda oddiy (kamida 8 ta belgi)";
      case 'network-request-failed':
        return "Internet aloqasi yo'q. Ulanishni tekshiring";
      case 'too-many-requests':
        return "Juda ko'p urinish. Birozdan keyin qayta urining";
      case 'user-disabled':
        return "Bu hisob bloklangan";
      case 'operation-not-allowed':
        return "Firebase'da Email/Parol usuli yoqilmagan";
      case 'requires-recent-login':
        return "Xavfsizlik uchun qayta kiring";
    }
    return "Xatolik: ${e.code}";
  }
  if (e is FirebaseException) {
    if (e.code == 'permission-denied') {
      return "Ruxsat yo'q. Firestore qoidalarini tekshiring";
    }
    if (e.code == 'unavailable') return "Internet aloqasi yo'q";
    return "Xatolik: ${e.code}";
  }
  return "Kutilmagan xatolik yuz berdi";
}
