import 'package:flutter/material.dart';
import '../core/theme.dart';

/// Qidiruv/kutish animatsiyasi.
class PulseRadar extends StatefulWidget {
  final IconData icon;
  final double size;
  const PulseRadar({super.key, this.icon = Icons.search_rounded, this.size = 190});

  @override
  State<PulseRadar> createState() => _PulseRadarState();
}

class _PulseRadarState extends State<PulseRadar>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 2400))
    ..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  Widget _ring(double t) {
    final s = widget.size * (0.35 + 0.65 * t);
    return Opacity(
      opacity: ((1 - t) * 0.6).clamp(0.0, 1.0),
      child: Container(
        width: s,
        height: s,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(color: AppColors.gold, width: 2),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: widget.size,
      height: widget.size,
      child: AnimatedBuilder(
        animation: _c,
        builder: (context, _) => Stack(
          alignment: Alignment.center,
          children: [
            for (var i = 0; i < 3; i++) _ring((_c.value + i / 3) % 1),
            Container(
              width: widget.size * 0.32,
              height: widget.size * 0.32,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: AppColors.navyLight,
              ),
              child: Icon(widget.icon, color: AppColors.gold, size: 34),
            ),
          ],
        ),
      ),
    );
  }
}
