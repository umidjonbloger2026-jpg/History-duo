/// Foydalanuvchiga to'g'ridan-to'g'ri ko'rsatiladigan xatolik.
class UserFacingException implements Exception {
  final String message;
  const UserFacingException(this.message);

  @override
  String toString() => message;
}
