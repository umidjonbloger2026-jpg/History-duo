import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'core/theme.dart';
import 'firebase_options.dart';
import 'screens/setup_error_screen.dart';
import 'screens/splash_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: AppColors.black,
    systemNavigationBarIconBrightness: Brightness.light,
  ));

  String? firebaseError;
  if (AppFirebaseOptions.isConfigured) {
    try {
      await Firebase.initializeApp(options: AppFirebaseOptions.options);
    } catch (e) {
      firebaseError = '$e';
    }
  } else {
    firebaseError = "firebase_options.dart fayli hali to'ldirilmagan.";
  }
  runApp(HistoryDuoApp(firebaseError: firebaseError));
}

class HistoryDuoApp extends StatelessWidget {
  final String? firebaseError;
  const HistoryDuoApp({super.key, this.firebaseError});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'HISTORY DUO',
      debugShowCheckedModeBanner: false,
      theme: buildAppTheme(),
      home: firebaseError == null
          ? const SplashScreen()
          : SetupErrorScreen(message: firebaseError!),
    );
  }
}
