HISTORY DUO — 8-BOSQICH

Codemagic uchun sinov APK va release AAB workflow'lari tayyorlandi. Firebase va TURN sozlamalarini kod ichiga yozmasdan, build vaqtida environment variables orqali berish yo‘li qo‘shildi. Android manifestda kamera ruxsati olib tashlanadi, mikrofon va internet ruxsatlari kiritiladi.

Batafsil sozlash va sinov tartibi: STAGE8_FINAL_CHECKLIST_UZ.md

OGOHLANTIRISH: Flutter SDK ushbu ish muhitida mavjud emas. Kodni compile qilish, APK/AAB yig‘ish yoki real qurilmalarda sinash bajarilmadi. Avval Codemagic'da debug APK yig‘ib, ikki telefonda tekshiring.
