HISTORY DUO - 6-BOSQICH

Qo'shilgan funksiyalar:
- 1-roundda xona participants[0] o'qiydi, ikkinchi ishtirokchi tinglaydi.
- O'quvchi "O'qib bo'ldim" tugmasini bosadi.
- Tinglovchi matnni ko'rmaydi; eshitganini ovoz orqali qayta aytadi.
- Tinglovchi "Javob berdim" tugmasini bosadi.
- O'qigan foydalanuvchi "To'g'ri" yoki "Xato" deb baholaydi.
- Bo'limlar navbat bilan davom etadi.
- 1-round tugagach 2-round boshlanadi va rollar almashadi.
- 2-round tugagach natijalar ko'rsatiladi.
- Ball faqat sherigi "To'g'ri" deb belgilagan javob uchun qo'shiladi.
- Tasodifiy va do'st orqali ulanishda ikkala foydalanuvchi aynan bir xil kitob/mavzuni tanlashi shart.

MUHIM:
- Firebase sozlamalari (firebase_options.dart) hali o'zingizning Firebase loyihangizga moslanishi kerak.
- Firestore rules'ni Firebase Console'ga joylang.
- Ovozli WebRTC aloqasi uchun TURN server konfiguratsiyasi ham kerak bo'lishi mumkin.
- Bu bosqichda Android AAB hali yig'ilmagan.
- Flutter SDK ushbu ish muhitida mavjud bo'lmagani sababli `flutter analyze` yoki build sinovi bajarilmadi.
