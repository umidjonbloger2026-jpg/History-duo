HISTORY DUO — 7-BOSQICH

6-bosqich loyihasi asos qilib olindi. Quyidagilar qo'shildi:

1) NATIJALAR TARIXI
- Har bir foydalanuvchi uchun yakunlangan xona users/{uid}/sessions/{roomId} ichida saqlanadi.
- Natijalar sahifasi mashg'ulotlar soni, to'plangan ball, maksimal imkoniyat va oxirgi mashg'ulotlarni ko'rsatadi.
- Saqlash xona ID bo'yicha takrorlanmas hujjatga yoziladi.

2) XAVFSIZLIK
- Xona oynasida sherik uchun menyu qo'shildi.
- Foydalanuvchini bloklash users/{uid}.blocked ro'yxatiga yozadi; mavjud MatchService bloklangan foydalanuvchilarni moslashtirmaslik uchun tekshiradi.
- Shikoyat sabablari tanlanadi va reports kolleksiyasiga yoziladi.
- Firestore rules shikoyatni faqat shu xonaning ishtirokchisiga yuborishga ruxsat beradi; shikoyatlar oddiy foydalanuvchilarga o'qish uchun ochilmagan.

3) BOSHQARUV / SINOV
- Home sahifasidagi "Mening natijalarim" tugmasi haqiqiy natijalar sahifasiga ulandi.
- Firestore rules ichiga sessions va reports qoidalari qo'shildi.

SOZLASH:
- Firebase Console > Firestore Database > Rules bo'limiga ushbu ZIP ichidagi firestore.rules faylini joylang va Publish bosing.
- Firebase Authentication Email/Password usuli yoqilgan bo'lishi kerak.
- Ilovaning firebase_options.dart faylini o'z Firebase loyihangizga moslang.

QO'LDA SINASH TARTIBI:
1. Ikki alohida test akkaunt bilan kiring.
2. Ikkalasi bir xil kitob va mavzuni tanlab tasodifiy ulanadi.
3. Ikkala roundni oxirigacha bajaring; ikkala qurilmada ham ballar bir xil ko'rinishini tekshiring.
4. Har ikkala akkauntda "Mening natijalarim" sahifasini ochib, sessiya alohida saqlanganini tekshiring.
5. Xonada sherik menyusidan shikoyat yuborish va bloklashni sinang.
6. Bloklangan ikki akkaunt keyingi tasodifiy qidiruvda bir-biriga ulanmasligini tekshiring.
7. Internetni uzib/ulab, xatolik xabarlari va qayta ulanishni sinang.

MUHIM CHEKLOVLAR:
- Bu muhitda Flutter/Dart SDK mavjud emas; flutter analyze, Android build yoki haqiqiy ikki qurilmali test bajarilmadi.
- Firebase loyihasi va haqiqiy TURN server sozlamalari kiritilmaguncha onlayn ovozli aloqa to'liq tasdiqlanmagan.
- Shikoyatlar Firestore'da saqlanadi, lekin moderator/admin paneli hali yo'q. Shikoyatlarni ko'rib chiqish uchun alohida himoyalangan admin jarayoni kerak.
- Play Marketga chiqarish va AAB yig'ish bu bosqichga kirmaydi.
