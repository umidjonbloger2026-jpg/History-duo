# HISTORY DUO — 8-bosqich: yakuniy yig‘ish va sinov

## Ushbu bosqichda tayyorlanganlar
- Codemagic uchun alohida sinov APK va release AAB workflow qo‘shildi.
- Firebase qiymatlari endi Dart `--dart-define` orqali berilishi mumkin; maxfiy qiymatlar kodga yozilmaydi.
- TURN server qiymatlari ham build vaqtida uzatilishi mumkin.
- Android manifestda internet va mikrofon ruxsatlari kiritiladi, kamera ruxsati olib tashlanadi.
- Ilova nomi `HISTORY DUO` qilib belgilanadi.

## 1. Avval sinov APK oling
1. ZIP ichidagi `history_duo_stage7_work` papkasini GitHub repository'ga yuklang.
2. Codemagic'da repository'ni ulang.
3. `codemagic.yaml` topilganini tekshiring.
4. `history-duo-debug` workflow'ni ishga tushiring.
5. Build muvaffaqiyatli tugasa, artifact bo‘limidan APK faylni yuklab, Android telefonga o‘rnating.

## 2. Firebase sozlash
Firebase Console'da Android ilova yarating. Package ID: `uz.historyduo.history_duo`.
Authentication ichida Email/Password usulini yoqing. Firestore Database yarating va ZIP ichidagi `firestore.rules` qoidalarini joylashtiring.

Codemagic > Environment variables bo‘limiga quyidagilarni kiriting:
- `FIREBASE_API_KEY`
- `FIREBASE_APP_ID`
- `FIREBASE_MESSAGING_SENDER_ID`
- `FIREBASE_PROJECT_ID`

Ovozli aloqa uchun STUN bilan birga TURN server ham kerak bo‘lishi mumkin. TURN ma’lumotlarini Codemagic'da maxfiy environment variables sifatida kiriting:
- `METERED_APP`, `METERED_KEY` yoki
- `TURN_URL`, `TURN_USERNAME`, `TURN_CREDENTIAL`

TURN ma’lumotlari bo‘lmasa, ayrim mobil tarmoqlarda ikki foydalanuvchi ovozli ulana olmasligi mumkin.

## 3. Haqiqiy qurilmalarda tekshirish
- Ikki alohida Android telefon va ikki alohida akkaunt bilan sinang.
- Ro‘yxatdan o‘tish/kirish ishlashini tekshiring.
- Bir-birini tasodifiy topishini tekshiring.
- Mikrofon ruxsati so‘ralishini va ovoz ikki tomonga uzatilishini tekshiring.
- Ikkala round, navbat almashishi va ballar ikkala telefonda bir xil bo‘lishini tekshiring.
- Bloklash va shikoyat yuborishni tekshiring.
- Ilovani yopib qayta ochish, internet uzilishi va qayta ulanishni sinang.

## 4. Release AAB
Firebase environment variables to‘ldirilgandan keyin Codemagic'da `history-duo-release-aab` workflow'ni ishga tushiring. Natija `build/app/outputs/bundle/release/` ichida AAB bo‘ladi.

Play Marketga chiqarishdan oldin Android release signing (keystore) sozlanishi shart. Keystore va parollarni ZIP yoki GitHub'ga qo‘ymang; Codemagic'ning Android code signing / secure files imkoniyatidan foydalaning.

## Hozirgi muhim cheklovlar
- Ushbu muhitda Flutter va Dart SDK o‘rnatilmagan. Shu sabab `flutter analyze`, APK/AAB build yoki qurilma sinovi bajarilmadi.
- Firebase loyihasi, Firestore rules, Authentication va TURN server foydalanuvchi tomonidan sozlanishi kerak.
- Kodning mavjudligi uning real qurilmada ishlashini isbotlamaydi. Avval debug APK bilan ikki telefonda sinovdan o‘tkazing.
- Bu bosqich Play Marketga avtomatik nashr qilmaydi; faqat release AAB yig‘ish jarayonini tayyorlaydi.
